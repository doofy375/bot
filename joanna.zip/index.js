const Discord=require('discord.js');
const{prefix,token}=require('./config.json');
const client=new Discord.Client();

var profanties=["fuck","damn","jesus","nigger","shit","crap"];

client.once('ready',()=>{
  console.log("ready");
});

client.on('message',message=>{
  console.log(message.content);
  for(i=0;i<profanties.length;i++){
    if(message.content.toLowerCase().includes(profanties[i])){
      message.channel.send("That's a bad word!!!");
      message.delete();
    }
  }
});
client.login(token);
